package com.example.appreparto.activity

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.appreparto.databinding.ActivityNotificationBinding
import com.example.appreparto.model.Notificacion
import com.example.appreparto.repository.NotificationRepository
import com.example.appreparto.viewmodel.NotificationViewModel
import com.example.appreparto.viewmodel.NotificationViewModelFactory
import kotlinx.coroutines.launch
import java.util.*

class NotificationActivity : AppCompatActivity() {
    private lateinit var binding: ActivityNotificationBinding
    private val eventId: Int by lazy { intent.getIntExtra("eventId", -1) }

    // Asegúrate de que tu factory acepte contexto y eventId; si no, lo ajustamos.
    private val viewModel: NotificationViewModel by viewModels {
        NotificationViewModelFactory(this, eventId)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Ajustar padding top para status bar + display cutout
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, insets ->
            val topInset = insets.getInsets(
                WindowInsetsCompat.Type.statusBars() or
                        WindowInsetsCompat.Type.displayCutout()
            ).top
            view.setPadding(
                view.paddingLeft,
                topInset + view.paddingTop,  // conserva el padding XML original
                view.paddingRight,
                view.paddingBottom
            )
            insets
        }

        // RecyclerView + LayoutManager
        val adapter = NotifAdapter()
        binding.rvNotificaciones.layoutManager = LinearLayoutManager(this)
        binding.rvNotificaciones.adapter = adapter

        // Observamos los cambios
        viewModel.notificaciones.observe(this) { lista ->
            adapter.submitList(lista)
        }

        // Repositorio para insertar nuevas notificaciones
        val repo = NotificationRepository(this)

        // FAB inyecta nueva notificación en tiempo real
        binding.fabAdd.setOnClickListener {
            val mensaje = "Nueva notificación ${Random().nextInt(10000)}"
            lifecycleScope.launch {
                repo.add(
                    Notificacion(
                        id = 0, // Room autogenera
                        eventId = eventId,
                        mensaje = mensaje,
                        fechaHora = System.currentTimeMillis()
                    )
                )
                viewModel.refresh()
            }
        }
    }
}
