package com.example.appreparto.worker

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.appreparto.R
import com.example.appreparto.activity.NotificationActivity
import com.example.appreparto.model.Notificacion
import com.example.appreparto.repository.NotificationRepository

class NotificationWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    private val repo = NotificationRepository(context)

    override suspend fun doWork(): Result {
        return try {
            val now = System.currentTimeMillis()
            val pending: List<Notificacion> = repo.getPendingToNotify(now)

            for (n in pending) {
                showNotification(n)
                repo.markNotified(n.id)
            }

            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        }
    }

    private fun showNotification(n: Notificacion) {
        val channelId = "CANAL_NOTIF"
        val notificationId = (n.id % Int.MAX_VALUE).toInt()

        // Intent para abrir detalle al tocar la notificación
        val intent = Intent(applicationContext, NotificationActivity::class.java).apply {
            putExtra("eventId", n.eventId)
            putExtra("mensaje", n.mensaje)
            putExtra("fechaHora", n.fechaHora)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntentFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val pendingIntent = PendingIntent.getActivity(
            applicationContext,
            notificationId,
            intent,
            pendingIntentFlags
        )

        val smallIcon = try {
            R.drawable.ic_notification
        } catch (e: Exception) {
            // fallback si no existe
            R.drawable.ic_launcher_foreground
        }

        val builder = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(smallIcon)
            .setContentTitle("Recordatorio")
            .setContentText(n.mensaje)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        val nm = NotificationManagerCompat.from(applicationContext)

        // Nota: en Android 13+ se requiere permiso POST_NOTIFICATIONS; se asume que la UI ya lo pidió.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // areNotificationsEnabled() no verifica permiso explícito, pero evita que falle si están deshabilitadas
            if (!nm.areNotificationsEnabled()) return
        }
        nm.notify(notificationId, builder.build())
    }
}
